#ifndef STRING_H
#define STRING_H

#include "types.h"

/* Memory */
void*  memcpy(void* dst, const void* src, size_t n);
void*  memset(void* dst, int c, size_t n);
void*  memmove(void* dst, const void* src, size_t n);
int    memcmp(const void* a, const void* b, size_t n);
void*  memchr(const void* s, int c, size_t n);

/* C strings (ASCII / UTF-8 byte length) */
size_t strlen(const char* s);
size_t strnlen(const char* s, size_t max);
char*  strcpy(char* dst, const char* src);
char*  strncpy(char* dst, const char* src, size_t n);
int    strcmp(const char* a, const char* b);
int    strncmp(const char* a, const char* b, size_t n);
char*  strcat(char* dst, const char* src);
char*  strncat(char* dst, const char* src, size_t n);
char*  strchr(const char* s, int c);
char*  strrchr(const char* s, int c);
char*  strstr(const char* haystack, const char* needle);
char*  strdup(const char* s);          /* uses kmalloc */
char*  strndup(const char* s, size_t n);
size_t strcspn(const char* s, const char* reject);
size_t strspn(const char* s, const char* accept);
char*  strtok(char* str, const char* delim);

#endif /* STRING_H */
